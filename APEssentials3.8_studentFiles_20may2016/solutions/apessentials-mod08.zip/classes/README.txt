
In order to successfully run the application, you must first edit the apessentials.xml file 
(either in the XML or by editing the global element through the visual GUI)
and add values for your Salesforce Developer account credentials.

